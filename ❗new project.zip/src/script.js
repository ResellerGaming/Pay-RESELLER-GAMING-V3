const API_CREATE = "https://api.nvidiabotz.xyz/orderkuota/createpayment";
const API_MUTASI = "https://api.nvidiabotz.xyz/orderkuota/mutasiqr?username=ahmadi1585&token=1607316:Yl1G70Ethw6S2mHOTBsQVgiNnP9fpRcj";

let currentAmount = null;
let currentIdTransaksi = null;

async function createPayment() {
  const amount = document.getElementById("amount").value;
  if (!amount || amount < 1) {
    alert("Masukkan minimal Rp1000");
    return;
  }

  const codeqr = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214357488533903180303UMI51440014ID.CO.QRIS.WWW0215ID20254010026420303UMI5204541153033605802ID5922TOKO RESMING OK16073166015PADANGSIDIMPUAN61052271162070703A016304E7C8";
  const url = `${API_CREATE}?amount=${amount}&codeqr=${encodeURIComponent(codeqr)}`;

  const res = await fetch(url);
  const data = await res.json();

  if (data.status === true && data.result?.imageqris?.url) {
    currentAmount = parseInt(amount);
    currentIdTransaksi = data.result.idtransaksi;

    document.getElementById("form-section").style.display = "none";
    document.getElementById("qr-section").style.display = "block";
    document.getElementById("qr-image").src = data.result.imageqris.url;

    pollPayment();
  } else {
    alert("Gagal membuat pembayaran: " + (data.error || "Unknown error"));
  }
}

function pollPayment() {
  const createdAt = Date.now();
  const interval = setInterval(async () => {
    const res = await fetch(API_MUTASI);
    const data = await res.json();

    if (data.status === true && Array.isArray(data.result)) {
      // Ambil transaksi masuk terbaru dengan nominal sama
      const paid = data.result
        .filter(tx => parseInt(tx.kredit) === currentAmount && tx.status === "IN")
        .sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal))[0];

      // Validasi: transaksi harus dalam 5 menit terakhir
      if (paid) {
        const txTime = new Date(paid.tanggal.replace(/(\d{2})\/(\d{2})\/(\d{4})/, '$3-$2-$1'));
        const diffMinutes = (Date.now() - txTime.getTime()) / 1000 / 60;

        if (diffMinutes <= 5) {
          clearInterval(interval);
          showSuccess();
        }
      }
    }
  }, 3000);
}


function showSuccess() {
  document.getElementById("qr-section").style.display = "none";
  document.getElementById("success-section").style.display = "block";
  document.getElementById("trans-id").textContent = currentIdTransaksi;
  document.getElementById("trans-amount").textContent = currentAmount.toLocaleString();
}

function resetPage() {
  location.reload();
}
